from django.test import TestCase
from accounts.models import *
from blog.models import *


class TestPostModel(TestCase):
    """a test for test model in data base"""

    def setUp(self):
        self.post = Post.objects.get(id=1)

    def test_post_existed(self):
        """checking post is exist or not"""
        self.assertTrue(self.post)

    def test_post_equals(self):
        """
        cheking post is runners created post or not
        (runner module is in core directory and when you run tests its runns runners commands)
        """
        self.assertEqual(self.post.title, "first post for test category")

from django.test import TestCase
from django.utils.timezone import now
from blog.forms import CreatePostForm
from blog.models import *
from accounts.models import *


class TestPostForm(TestCase):
    """testing blog forms"""

    def test_create_post_form(self):
        """checks form's validation"""

        form = CreatePostForm(
            data={
                "author": Profile.objects.get(id=1),
                "category": Category.objects.get(id=1),
                "title": "title for testing",
                "content": "content data for testing",
                "status": True,
                "published_at": now(),
            }
        )
        self.assertTrue(form.is_valid())

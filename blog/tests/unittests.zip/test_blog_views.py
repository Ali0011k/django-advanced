from django.test import TestCase
from django.urls import reverse
from accounts.models import User
from blog.models import Post


class TestBlogViews(TestCase):
    """testing blog views"""

    def setUp(self):
        self.user = User.objects.get(id=1)
        self.post = Post.objects.get(id=1)

    def test_index_view(self):
        url = reverse("blog:cbv-index")
        response = self.client.get(url)
        # checking response status code is valid
        self.assertEqual(response.status_code, 200)
        # checking response's template name
        self.assertTemplateUsed(response, "index.html")
        # checking this content is exist or not
        self.assertTrue(str(response.content).find("index"))

    def test_post_detail_status_code_logged_in(self):
        # testing url with logged in user
        self.client.force_login(user=self.user)
        url = reverse("blog:post-detail", kwargs={"pk": self.post.id})
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_post_detail_status_code_anonymous(self):
        # testing url with out logged in user
        url = reverse("blog:post-detail", kwargs={"pk": self.post.id})
        response = self.client.get(url)
        self.assertEqual(response.status_code, 302)

from django.test import TestCase
from django.urls import reverse, resolve
from blog.views import *


class TestUrls(TestCase):
    """a test for blog urls"""

    def test_index_view_resolve(self):
        """
        checks urls class name is equal with this class or not

        use this for function based views
        self.assertEqual(resolve(url).func, IndexView)

        """
        url = reverse("blog:cbv-index")
        self.assertEqual(resolve(url).func.view_class, IndexView)

    def test_blog_detail_resolve(self):
        """
        checks urls class name is equal with this class or not

        use this for function based views
        self.assertEqual(resolve(url).func, IndexView)

        """
        url = reverse("blog:post-detail", kwargs={"pk": 1})
        self.assertEqual(resolve(url).func.view_class, PostDetail)

    def test_blog_list_resolve(self):
        """
        checks urls class name is equal with this class or not

        use this for function based views
        self.assertEqual(resolve(url).func, IndexView)

        """
        url = reverse("blog:PostList-cbv")
        self.assertEqual(resolve(url).func.view_class, PostList)
